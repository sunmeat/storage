﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labyrinth.Weapons
{
    internal class Weapon
    {
        protected int cost;
        protected bool purchased;
        protected int energy;
    }
}
